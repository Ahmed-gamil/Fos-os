#include <inc/lib.h>




// malloc()
//	This function use NEXT FIT strategy to allocate space in heap
//  with the given size and return void pointer to the start of the allocated space

//	To do this, we need to switch to the kernel, allocate the required space
//	in Page File then switch back to the user again.
//
//	We can use sys_allocateMem(uint32 virtual_address, uint32 size); which
//		switches to the kernel mode, calls allocateMem(struct Env* e, uint32 virtual_address, uint32 size) in
//		"memory_manager.c", then switch back to the user mode here
//	the allocateMem function is empty, make sure to implement it.

//==================================================================================//
//============================ REQUIRED FUNCTIONS ==================================//
//==================================================================================//
struct kheap
{
	uint32 *address;
	int pages;
};
struct kheap arr[4016];

uint32 nextfit_address=KERNEL_HEAP_START;
int idx=0;








struct va
{
	uint32 adress;
	int flag;
};
struct va vas[131072];
int index=0;
int fl=0;
void* malloc(uint32 size)
{
	uint32 temp=USER_HEAP_START;
	if(fl==0)
	{
		for(int i=0;i<131072;i++)
		{
			vas[i].adress=temp;
			vas[i].flag=0;
			temp+=PAGE_SIZE;
		}
		fl++;
	}

	//TODO: [PROJECT 2018 - MS2 - [4] User Heap] malloc() [User Side]
	// Write your code here, remove the panic and write your code


	// Steps:
	//	1) Implement NEXT FIT strategy to search the heap for suitable space
	//		to the required allocation size (space should be on 4 KB BOUNDARY)
	//	2) if no suitable space found, return NULL
	//	 Else,
	//	3) Call sys_allocateMem to invoke the Kernel for allocation
	// 	4) Return pointer containing the virtual address of allocated space,
	//

	//This function should find the space of the required range
	// ******** ON 4KB BOUNDARY ******************* //

	//Use sys_isUHeapPlacementStrategyNEXTFIT()
	//to check the current strategy
	uint32 start_address;
		int no_of_pages=(size/PAGE_SIZE);
		if(size%PAGE_SIZE!=0)
			no_of_pages++;

	int flag=0;
	int flag1=0;
	int counter=0;
	int start=nextfit_address;
int tindex=index;
	while(1==1)
	{
		if(start>KERNEL_HEAP_MAX)
			start=KERNEL_HEAP_START;
		if((tindex==131071)&&(counter!=no_of_pages)&&(flag==0))
		{
			counter=0;
			tindex=0;
			flag=1;
			start_address=vas[tindex].adress;

		}
		else if((tindex==131071)&&(counter!=no_of_pages)&&(flag==1))
		{
			return NULL;
		}
		if(counter==no_of_pages)
		{
			start_address=vas[tindex].adress-(counter*PAGE_SIZE);
			break;
		}


		if(vas[tindex].flag==0)
		{
			counter++;
			tindex++;
		}
		else

		{
			counter=0;
			tindex++;

		}

	}

index=tindex;
	int x=start_address;
sys_allocateMem(start_address,no_of_pages);
	arr[idx].address=(void*)x;
			arr[idx].pages=no_of_pages;
			idx++;
	nextfit_address=start;
			return (void*)x;


	return 0;
}

// free():
//	This function frees the allocation of the given virtual_address
//	To do this, we need to switch to the kernel, free the pages AND "EMPTY" PAGE TABLES
//	from page file and main memory then switch back to the user again.
//
//	We can use sys_freeMem(uint32 virtual_address, uint32 size); which
//		switches to the kernel mode, calls freeMem(struct Env* e, uint32 virtual_address, uint32 size) in
//		"memory_manager.c", then switch back to the user mode here
//	the freeMem function is empty, make sure to implement it.

void free(void* virtual_address)
{
	//TODO: [PROJECT 2018 - MS2 - [4] User Heap] free() [User Side]
	// Write your code here, remove the panic and write your code

	//you shold get the size of the given allocation using its address
	//you need to call sys_freeMem()
	//refer to the project presentation and documentation for details
uint32 start,siz,z;
for(int i=0;i<idx;i++)
{
	if(virtual_address==arr[i].address)
	{
		start=(uint32)arr[i].address;
		siz=arr[i].pages;
		arr[i].address=0;
		arr[i].pages=0;
		break;
	}

}
int x;
for(int i=0;i<131072;i++)
{
	if(start==vas[i].adress)
	{
		 x=i;
		break;
	}
}

for(int i=0;i<siz;i++)
{
	vas[x].flag=0;
	x++;
}

sys_freeMem((uint32)virtual_address,siz);

}

//==================================================================================//
//============================== BONUS FUNCTIONS ===================================//
//==================================================================================//

//===============
// [2] realloc():
//===============

//	Attempts to resize the allocated space at "virtual_address" to "new_size" bytes,
//	possibly moving it in the heap.
//	If successful, returns the new virtual_address, in which case the old virtual_address must no longer be accessed.
//	On failure, returns a null pointer, and the old virtual_address remains valid.

//	A call with virtual_address = null is equivalent to malloc().
//	A call with new_size = zero is equivalent to free().

//  Hint: you may need to use the sys_moveMem(uint32 src_virtual_address, uint32 dst_virtual_address, uint32 size)
//		which switches to the kernel mode, calls moveMem(struct Env* e, uint32 src_virtual_address, uint32 dst_virtual_address, uint32 size)
//		in "memory_manager.c", then switch back to the user mode here
//	the moveMem function is empty, make sure to implement it.

void *realloc(void *virtual_address, uint32 new_size)
{
	//TODO: [PROJECT 2018 - BONUS3] User Heap Realloc [User Side]
	// Write your code here, remove the panic and write your code
	panic("realloc() is not implemented yet...!!");

	return NULL;
}



//==================================================================================//
//============================= OTHER FUNCTIONS ====================================//
//==================================================================================//

void expand(uint32 newSize)
{
}

void shrink(uint32 newSize)
{
}

void freeHeap(void* virtual_address)
{
	return;
}


//=============
// [1] sfree():
//=============
//	This function frees the shared variable at the given virtual_address
//	To do this, we need to switch to the kernel, free the pages AND "EMPTY" PAGE TABLES
//	from main memory then switch back to the user again.
//
//	use sys_freeSharedObject(...); which switches to the kernel mode,
//	calls freeSharedObject(...) in "shared_memory_manager.c", then switch back to the user mode here
//	the freeSharedObject() function is empty, make sure to implement it.

void sfree(void* virtual_address)
{
	//[] Free Shared Variable [User Side]
	// Write your code here, remove the panic and write your code
	//panic("sfree() is not implemented yet...!!");

	//	1) you should find the ID of the shared variable at the given address
	//	2) you need to call sys_freeSharedObject()

}

void* smalloc(char *sharedVarName, uint32 size, uint8 isWritable)
{
	//[[6] Shared Variables: Creation] smalloc() [User Side]
	// Write your code here, remove the panic and write your code
	panic("smalloc() is not implemented yet...!!");

	// Steps:
	//	1) Implement FIRST FIT strategy to search the heap for suitable space
	//		to the required allocation size (space should be on 4 KB BOUNDARY)
	//	2) if no suitable space found, return NULL
	//	 Else,
	//	3) Call sys_createSharedObject(...) to invoke the Kernel for allocation of shared variable
	//		sys_createSharedObject(): if succeed, it returns the ID of the created variable. Else, it returns -ve
	//	4) If the Kernel successfully creates the shared variable, return its virtual address
	//	   Else, return NULL

	//This function should find the space of the required range
	// ******** ON 4KB BOUNDARY ******************* //

	//Use sys_isUHeapPlacementStrategyFIRSTFIT() to check the current strategy

	return 0;
}

void* sget(int32 ownerEnvID, char *sharedVarName)
{
	//[[6] Shared Variables: Get] sget() [User Side]
	// Write your code here, remove the panic and write your code
	panic("sget() is not implemented yet...!!");

	// Steps:
	//	1) Get the size of the shared variable (use sys_getSizeOfSharedObject())
	//	2) If not exists, return NULL
	//	3) Implement FIRST FIT strategy to search the heap for suitable space
	//		to share the variable (should be on 4 KB BOUNDARY)
	//	4) if no suitable space found, return NULL
	//	 Else,
	//	5) Call sys_getSharedObject(...) to invoke the Kernel for sharing this variable
	//		sys_getSharedObject(): if succeed, it returns the ID of the shared variable. Else, it returns -ve
	//	6) If the Kernel successfully share the variable, return its virtual address
	//	   Else, return NULL
	//

	//This function should find the space for sharing the variable
	// ******** ON 4KB BOUNDARY ******************* //

	//Use sys_isUHeapPlacementStrategyFIRSTFIT() to check the current strategy

	return NULL;
}

