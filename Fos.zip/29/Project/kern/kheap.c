#include <inc/memlayout.h>
#include <kern/kheap.h>
#include <kern/memory_manager.h>
struct kheap
{
	uint32 *address;
	int pages;
};
struct kheap arr[4016];

uint32 nextfit_address=KERNEL_HEAP_START;
int idx=0;
int a;
void* kmalloc(unsigned int size)
{
	uint32 start_address;
	int no_of_pages=(size/PAGE_SIZE)+(size%PAGE_SIZE!=0);
	int flag=0,flag1=0,counter=0,start=nextfit_address;
	while(1==1)
	{
		if(start>KERNEL_HEAP_MAX)
			start=KERNEL_HEAP_START;
		if((start==KERNEL_HEAP_MAX)&&(counter!=no_of_pages)&&(flag==0))
		{
			counter=0;
			start=KERNEL_HEAP_START;
			flag=1;
			start_address=KERNEL_HEAP_START;

		}
		else if((start==KERNEL_HEAP_MAX)&&(counter!=no_of_pages)&&(flag==1))
			return NULL;
		if(counter==no_of_pages)
		{
			start_address=start-(counter*PAGE_SIZE);
			break;
		}
		struct Frame_Info *ptr;
		uint32 *ptr_page;
		ptr=get_frame_info(ptr_page_directory,(void*)start,&ptr_page);
		if(ptr==NULL)
			counter++;
		else
			counter=0;
		start+=PAGE_SIZE;
	}

	int x=start_address;
	for ( int i=0 ; i<no_of_pages ; i++,start_address+=PAGE_SIZE)
	{
		struct Frame_Info *FI=NULL;
		allocate_frame(&FI);
		map_frame(ptr_page_directory,FI,(void*)start_address,PERM_PRESENT|PERM_WRITEABLE);
	}
	arr[idx].address=(void*)x;
	arr[idx].pages=no_of_pages;
	idx++;
	nextfit_address=start;
	return (void*)x;



	//TODO: [PROJECT 2018 - BONUS1] Implement the BEST FIT strategy for Kernel allocation
	// Beside the NEXT FIT
	// use "isKHeapPlacementStrategyBESTFIT() ..." functions to check the current strategy

	//change this "return" according to your answer

}


void kfree(void* virtual_address)
{
	int pages;
	for (int i =0 ; i<idx ; i++)
	{
		if ( virtual_address==arr[i].address)
		{
			pages=arr[i].pages;
			arr[i].address=NULL;
			arr[i].pages=0;
			break;
		}
	}
	for ( int i=0 ; i<pages ; i++,virtual_address+=PAGE_SIZE)
		unmap_frame(ptr_page_directory,(void*)virtual_address);

}

unsigned int kheap_virtual_address(unsigned int physical_address)
{
	struct Frame_Info *ptr_frame;
	ptr_frame=to_frame_info(physical_address);
	for(int i=KERNEL_HEAP_START;i<nextfit_address;i+=PAGE_SIZE)
	{
		unsigned int *ptr;
		struct Frame_Info *ptr_frame1;
		ptr_frame1=get_frame_info(ptr_page_directory,(void*)i,&ptr);
		if(ptr_frame==ptr_frame1)
			return i;
	}
	return 0;

}

unsigned int kheap_physical_address(unsigned int virtual_address)
{
	int offset=virtual_address&0x00000fff;
	int x=PTX(virtual_address);
	unsigned int *ptr;
	get_page_table(ptr_page_directory,(void*)virtual_address,&ptr);
	int frame_number=ptr[x]&0xfffff000;
	int physc=frame_number+offset;
	return physc;

}


//=================================================================================//
//============================== BONUS FUNCTION ===================================//
//=================================================================================//
// krealloc():

//	Attempts to resize the allocated space at "virtual_address" to "new_size" bytes,
//	possibly moving it in the heap.
//	If successful, returns the new virtual_address, in which case the old virtual_address must no longer be accessed.
//	On failure, returns a null pointer, and the old virtual_address remains valid.

//	A call with virtual_address = null is equivalent to kmalloc().
//	A call with new_size = zero is equivalent to kfree().

void *krealloc(void *virtual_address, uint32 new_size)
{
	//TODO: [PROJECT 2018 - BONUS2] Kernel Heap Realloc
	// Write your code here, remove the panic and write your code

	return NULL;
	panic("krealloc() is not implemented yet...!!");

}
